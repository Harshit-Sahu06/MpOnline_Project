# 🇮🇳 MPOnline Project — AI-Powered Career Readiness & Employability Platform

> **An AI-powered career readiness platform that helps students understand where they stand today, identify their skill gaps, discover relevant opportunities, improve their resumes, and prepare for interviews.**

[![React](https://img.shields.io/badge/React-19-61DAFB?logo=react&logoColor=111827)](https://react.dev/)
[![Vite](https://img.shields.io/badge/Vite-8-646CFF?logo=vite&logoColor=white)](https://vite.dev/)
[![Node.js](https://img.shields.io/badge/Node.js-Express-339933?logo=node.js&logoColor=white)](https://nodejs.org/)
[![Google Gemini](https://img.shields.io/badge/AI-Gemini_2.5_Flash-4285F4?logo=google&logoColor=white)](https://ai.google.dev/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

---

## 📌 Overview

The **MPOnline Project** is a full-stack employability platform designed around the **Campus-to-Corporate** journey. It combines student profiling, academic information, skill benchmarking, AI-powered analysis, learning recommendations, job matching, government opportunities, resume optimization, and mock interviews into one workflow.

The platform is designed to answer five practical questions:

1. **Where am I today?** → Employability score and skill profile
2. **What am I missing?** → AI-driven skill-gap analysis
3. **What should I learn next?** → Personalized roadmap and course recommendations
4. **Where can I apply?** → Job, internship, and government opportunity matching
5. **Am I ready to apply?** → ATS resume review and AI mock interviews

---

## 🎯 Core Problem

Students often have fragmented information about academics, skills, resumes, courses, and employment opportunities. The result is a gap between **academic completion** and **job readiness**.

This project brings these pieces together into a single personalized career-readiness workflow.

---

## ✨ Key Features

| Module | What it does |
|---|---|
| 🔐 Authentication | Registration, login, JWT sessions, role-based student/admin experience |
| 🧑‍🎓 Student Profile | Academic, CGPA, target role, skills, resume/profile information |
| 🧠 AI Skill Assessment | Calculates employability readiness and identifies skill gaps |
| 🗺️ Personalized Roadmap | Converts identified gaps into phased action plans |
| 📚 Course Catalog | Recommends learning content around identified gaps |
| 💼 Job Matcher | Displays relevant internships and entry-level opportunities |
| 🏛️ Government Opportunities | Surfaces government jobs/apprenticeships and eligibility information |
| 📄 ATS Resume Reviewer | Reviews resumes, finds missing keywords, and suggests stronger bullets |
| 🎤 Mock Interview | Simulates interviews and evaluates answers using AI |
| 📊 Admin Analytics | Placement-oriented student analytics and student selection |
| 🌗 Theme Support | Light/dark application experience |
| 🤖 AI Fallback | Works with a deterministic simulated engine when Gemini is unavailable |

---

## 🧩 High-Level Architecture

```mermaid
flowchart LR
    U[Student / Admin] --> FE[React + Vite Frontend]
    FE --> AUTH[Authentication Layer]
    FE --> API[Express REST API]
    FE --> LOCAL[Client-side Profile / Demo Data]
    API --> AI[Google Gemini 2.5 Flash]
    API --> JOBS[Jobs & Government Opportunities]
    API --> JWT[JWT Authentication]
    AI --> ANALYSIS[Profile Analysis]
    AI --> RESUME[ATS Resume Review]
    ANALYSIS --> DASH[Skill Gap Dashboard]
    DASH --> ROADMAP[Personalized Roadmap]
    ROADMAP --> COURSES[Course Recommendations]
    DASH --> MATCH[Job Matching]
    FE --> INTERVIEW[AI Mock Interview]
    INTERVIEW --> AI
```

---

## 🔄 Complete Student Journey

```mermaid
flowchart TD
    A[Open Platform] --> B{Authenticated?}
    B -- No --> C[Register / Login]
    B -- Yes --> D[Load Student Profile]
    C --> D
    D --> E[Onboarding Survey]
    E --> F[Select Sector & Target Role]
    F --> G[Upload / Enter Academic & Resume Data]
    G --> H[AI Employability Assessment]
    H --> I[Employability Score]
    H --> J[Skill Gap Analysis]
    J --> K[Personalized Roadmap]
    K --> L[Recommended Courses]
    I --> M[Job & Internship Matching]
    M --> N[Government Opportunities]
    D --> O[Resume ATS Review]
    O --> P[Resume Improvements]
    D --> Q[Mock Interview]
    Q --> R[Interview Feedback]
    L --> S[Track Readiness]
    P --> S
    R --> S
    N --> S
```

---

## 🧠 AI Employability Assessment Flow

```mermaid
flowchart TD
    A[Student Profile] --> B[Academic History]
    A --> C[Current Skills]
    A --> D[Target Role]
    A --> E[Resume]
    B --> F[Profile Context]
    C --> F
    D --> F
    E --> F
    F --> G{Gemini API Available?}
    G -- Yes --> H[Gemini 2.5 Flash]
    G -- No --> I[Deterministic Fallback Engine]
    H --> J[Structured JSON Analysis]
    I --> J
    J --> K[Employability Score]
    J --> L[Strengths]
    J --> M[Skill Gaps]
    J --> N[Recommendations]
    J --> O[Personalized Roadmap]
    K --> P[Dashboard]
    L --> P
    M --> P
    N --> P
    O --> P
```

---

## 📊 Skill-Gap Logic

The platform compares a student's current skill level with a target-role benchmark.

```mermaid
flowchart LR
    A[Current Skill Level] --> C[Compare With Target Benchmark]
    B[Required Skill Level] --> C
    C --> D{Gap Size}
    D -->|Small| E[Low Urgency]
    D -->|Medium| F[Medium Urgency]
    D -->|Large| G[High Urgency]
    E --> H[Recommended Learning]
    F --> H
    G --> H
    H --> I[Roadmap + Course Suggestions]
```

A simplified readiness calculation used by the frontend is:

```text
Employability Score ≈
Σ min(Student Skill Level, Industry Required Level)
----------------------------------------------- × 100
Σ Industry Required Level
```

The AI service can additionally return its own structured assessment when Gemini is configured.

---

## 🔐 Authentication & Authorization Flow

```mermaid
sequenceDiagram
    participant User
    participant React as React Frontend
    participant API as Express API
    participant JWT as JWT Service

    User->>React: Enter credentials
    React->>API: POST /api/auth/login
    API->>JWT: Sign token
    JWT-->>API: JWT
    API-->>React: User + token
    React->>React: Store session
    React->>API: Authorization: Bearer <token>
    API->>JWT: Verify token
    JWT-->>API: Valid / Invalid
    API-->>React: Protected response
```

> **Security note:** the current demo implementation contains in-memory demo users and fallback secrets for hackathon/demo purposes. Production deployment should use a persistent database, password hashing, secret management, refresh-token strategy, and proper authorization middleware.

---

## 📄 Resume Optimization Flow

```mermaid
flowchart TD
    A[Paste / Upload Resume Text] --> B[Select Target Role]
    B --> C[AI ATS Review]
    C --> D[ATS Score]
    C --> E[Missing Keywords]
    C --> F[Formatting Rating]
    C --> G[Original vs Suggested Bullets]
    G --> H[STAR / Impact-oriented Rewrite]
    D --> I[Resume Readiness]
    E --> I
    F --> I
    H --> I
```

---

## 🎤 Mock Interview Flow

```mermaid
flowchart LR
    A[Target Role] --> B[Interview Question]
    B --> C[Student Answer]
    C --> D[AI Evaluation]
    D --> E[Score]
    D --> F[Feedback]
    D --> G[Improvement Suggestions]
    G --> H[Next Practice Round]
    H --> B
```

---

## 🏛️ Admin / Placement Analytics Flow

```mermaid
flowchart TD
    A[Admin Login] --> B[Admin Dashboard]
    B --> C[Student Profiles]
    C --> D[Skill & Academic Data]
    D --> E[Placement Readiness Insights]
    E --> F[Select / Review Student]
    F --> G[Student Dashboard]
```

---

## 🗂️ Project Structure

```text
MpOnline_Project/
├── .github/
│   ├── ISSUE_TEMPLATE/
│   │   ├── bug_report.md
│   │   └── feature_request.md
│   ├── workflows/
│   │   └── ci.yml
│   └── pull_request_template.md
├── backend/
│   ├── middleware/
│   │   └── authMiddleware.js
│   ├── routes/
│   │   ├── aiRoutes.js
│   │   ├── authRoutes.js
│   │   └── jobRoutes.js
│   ├── .env.example
│   ├── package.json
│   ├── package-lock.json
│   ├── README.md
│   └── server.js
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── assets/
│   │   ├── components/
│   │   ├── data/
│   │   ├── services/
│   │   ├── App.jsx
│   │   ├── App.css
│   │   ├── index.css
│   │   └── main.jsx
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
├── .gitignore
├── .oxlintrc.json
├── package.json
├── LICENSE
├── CONTRIBUTING.md
└── README.md
```

---

## 🧱 Frontend Component Map

```mermaid
flowchart TD
    APP[App.jsx] --> AUTH[AuthPage]
    APP --> HEADER[Header]
    APP --> SIDEBAR[Sidebar]
    APP --> DASH[SkillGapDashboard]
    APP --> COURSES[CourseCatalog]
    APP --> JOBS[JobMatcher]
    APP --> RESUME[ResumeEnhancer]
    APP --> INTERVIEW[MockInterview]
    APP --> GOVT[GovtOpportunities]
    APP --> ADMIN[AdminDashboard]
    APP --> PROFILE[ProfileUploadModal]
    APP --> SURVEY[OnboardingSurveyModal]
    APP --> LOGIN[LoginModal]
    RESUME --> GEMINI[services/gemini.js]
    INTERVIEW --> GEMINI
    DASH --> GEMINI
    AUTH --> AUTH_SERVICE[services/auth.js]
```

---

## 🌐 REST API Map

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `/api/health` | Backend health check |
| `GET` | `/api/auth/personas` | Demo personas |
| `POST` | `/api/auth/register` | Register a user |
| `POST` | `/api/auth/login` | Authenticate a user |
| `GET` | `/api/auth/verify` | Verify JWT |
| `POST` | `/api/ai/analyze-profile` | AI profile/skill-gap analysis |
| `POST` | `/api/ai/review-resume` | AI ATS resume analysis |
| `GET` | `/api/jobs` | Job/internship opportunities |
| `GET` | `/api/govt-schemes` | Government opportunities |

### API request flow

```mermaid
flowchart LR
    CLIENT[React Client] --> ROUTER[Express Router]
    ROUTER --> AUTH_API[/auth/*]
    ROUTER --> AI_API[/ai/*]
    ROUTER --> JOB_API[/jobs + govt-schemes]
    AUTH_API --> JWT[JWT]
    AI_API --> GEMINI[Gemini]
    JOB_API --> DATA[Opportunity Data]
```

---

## 🛠️ Technology Stack

### Frontend
- React 19
- Vite 8
- Tailwind CSS 4
- Lucide React
- Recharts
- Google GenAI SDK

### Backend
- Node.js
- Express 4
- CORS
- dotenv
- JSON Web Tokens
- Google GenAI SDK

### Development
- VS Code friendly
- npm scripts
- Oxlint
- GitHub Actions CI

---

## 🚀 Local Setup

### Prerequisites

- Node.js 18+ recommended
- npm 9+
- Git
- Optional: Google Gemini API key

### 1. Clone the repository

```bash
git clone https://github.com/Harshit-Sahu06/MpOnline_Project.git
cd MpOnline_Project
```

### 2. Install frontend dependencies

```bash
cd frontend
npm install
```

### 3. Configure backend

```bash
cd ../backend
npm install
```

Create `.env` from `.env.example`:

```bash
# macOS/Linux
cp .env.example .env

# Windows PowerShell
Copy-Item .env.example .env
```

Configure:

```env
PORT=5000
NODE_ENV=development
JWT_SECRET=replace_with_a_long_random_secret
GEMINI_API_KEY=your_gemini_api_key
```

### 4. Start backend

```bash
cd backend
npm run dev
```

Backend health check:

```text
http://localhost:5000/api/health
```

### 5. Start frontend

Open another terminal:

```bash
cd frontend
npm run dev
```

Vite will provide the local development URL, normally:

```text
http://localhost:5173
```

---

## ▶️ Root Commands

From the project root:

```bash
npm run dev       # Start frontend
npm run build     # Build frontend
npm run backend   # Start backend
```

Frontend-only commands:

```bash
cd frontend
npm run dev
npm run build
npm run lint
npm run preview
```

Backend-only commands:

```bash
cd backend
npm run dev
npm start
```

---

## 🧪 Demo Personas

The current backend contains demo personas for development/testing:

| Role | Email | Password |
|---|---|---|
| Student | `rohan@campus.edu` | `password123` |
| Student | `sarah@campus.edu` | `password123` |
| Student | `alex@campus.edu` | `password123` |
| Admin | `admin@college.edu` | `admin123` |

> These credentials are for the demo environment only. Never use them in production.

---

## 🔁 Git & Branching Strategy

```mermaid
gitGraph
   commit id: "main"
   branch develop
   checkout develop
   commit id: "feature work"
   branch feature/ai-improvements
   checkout feature/ai-improvements
   commit id: "implementation"
   commit id: "tests/docs"
   checkout develop
   merge feature/ai-improvements
   checkout main
   merge develop tag: "v1.0.0"
```

Recommended branches:

```text
main                         → stable/release-ready code
develop                      → integration branch
feature/<name>               → new feature
fix/<name>                   → bug fix
hotfix/<name>                → urgent production fix
```

Recommended workflow:

```mermaid
flowchart LR
    A[Issue] --> B[Create Branch]
    B --> C[Implement]
    C --> D[Test + Lint]
    D --> E[Commit]
    E --> F[Push]
    F --> G[Pull Request]
    G --> H[Review]
    H --> I{Approved?}
    I -- No --> C
    I -- Yes --> J[Merge to Develop]
    J --> K[Release PR]
    K --> L[Main]
```

---

## 🤖 CI Pipeline

The repository includes GitHub Actions configuration for:

- dependency installation
- frontend build
- frontend linting
- backend syntax validation

```mermaid
flowchart LR
    A[Push / Pull Request] --> B[GitHub Actions]
    B --> C[npm ci - Frontend]
    C --> D[Lint]
    C --> E[Production Build]
    B --> F[npm ci - Backend]
    F --> G[Node Syntax Checks]
    D --> H{All Checks Pass?}
    E --> H
    G --> H
    H -- Yes --> I[Ready for Review]
    H -- No --> J[Fix & Push Again]
```

---

## 🔒 Security Considerations

The current project is a hackathon/demo implementation. Before production deployment:

- Hash passwords with Argon2 or bcrypt.
- Store users in a persistent database.
- Move all secrets to a secret manager/environment configuration.
- Remove hard-coded JWT fallback secrets.
- Never commit `.env` files.
- Validate and sanitize request bodies.
- Add rate limiting to authentication and AI endpoints.
- Add role-based authorization to protected API routes.
- Avoid accepting arbitrary user-provided API keys unless explicitly required and safely handled.
- Add audit logging for administrative actions.
- Add secure HTTP headers and HTTPS in production.

---

## 🗺️ Future Roadmap

```mermaid
flowchart TD
    A[Current Demo] --> B[Persistent Database]
    B --> C[Production Authentication]
    C --> D[Real Opportunity APIs]
    D --> E[Student Progress Tracking]
    E --> F[Institution Analytics]
    F --> G[Notifications & Alerts]
    G --> H[Deployment & Observability]
```

Potential next-stage improvements:

- PostgreSQL/MongoDB persistence
- Real MPOnline/government opportunity integrations where permitted
- Resume PDF parsing and OCR
- Skill extraction from GitHub/projects
- Calendar-based learning plans
- Email/SMS/WhatsApp notifications
- Institution-level dashboards
- Placement outcome analytics
- Multi-language support, including Hindi
- Production deployment with Docker

---

## 📁 Documentation

- Backend API documentation → [`backend/README.md`](backend/README.md)
- Contribution workflow → [`CONTRIBUTING.md`](CONTRIBUTING.md)
- Environment configuration → [`backend/.env.example`](backend/.env.example)
- CI workflow → [`.github/workflows/ci.yml`](.github/workflows/ci.yml)

---

## 🤝 Contributing

1. Create an issue describing the change.
2. Create a feature/fix branch.
3. Implement the change.
4. Run lint/build/tests available for the affected area.
5. Commit with a clear message.
6. Open a pull request into `develop`.
7. Address review feedback.
8. Merge after approval and passing CI.

See [`CONTRIBUTING.md`](CONTRIBUTING.md) for the detailed workflow.

---

## 📄 License

This project is released under the MIT License. See [`LICENSE`](LICENSE).

---

## 👨‍💻 Project

**MpOnline Project**  
AI-Powered Career Readiness & Employability Platform  
Built for student employability, skill discovery, and campus-to-corporate readiness.
