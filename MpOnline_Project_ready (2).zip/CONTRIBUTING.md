# Contributing to MPOnline Project

Thank you for contributing.

## Development Workflow

1. Create or select an issue.
2. Branch from `develop`:

```bash
git checkout develop
git pull origin develop
git checkout -b feature/short-description
```

3. Implement the change.
4. Run the relevant checks:

```bash
cd frontend
npm install
npm run lint
npm run build
```

```bash
cd ../backend
npm install
node --check server.js
node --check routes/authRoutes.js
node --check routes/aiRoutes.js
node --check routes/jobRoutes.js
```

5. Commit using a clear message:

```text
feat: add skill-gap export
fix: handle invalid JWT token
docs: improve API documentation
refactor: simplify dashboard data flow
```

6. Push the branch and open a pull request into `develop`.
7. Explain what changed, why it changed, and how it was tested.

## Pull Requests

Keep PRs focused. Avoid mixing unrelated refactors with feature work.

## Security

Do not commit secrets, `.env` files, API keys, passwords, tokens, or personal data.
