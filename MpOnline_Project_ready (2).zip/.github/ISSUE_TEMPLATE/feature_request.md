---
name: Feature request
about: Suggest an improvement or new capability
labels: enhancement
---

## Problem

What user problem should this solve?

## Proposed Solution

Describe the feature.

## Acceptance Criteria

- [ ] 
- [ ] 
- [ ] 

## Additional Context

