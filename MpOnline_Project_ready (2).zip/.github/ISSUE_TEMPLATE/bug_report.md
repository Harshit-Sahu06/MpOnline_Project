---
name: Bug report
about: Report a reproducible problem
labels: bug
---

## Description

Describe the bug clearly.

## Steps to Reproduce

1. 
2. 
3. 

## Expected Behavior

## Actual Behavior

## Environment

- OS:
- Node version:
- Browser:

## Logs / Screenshots

